<?php

unlink('token.json');

?>
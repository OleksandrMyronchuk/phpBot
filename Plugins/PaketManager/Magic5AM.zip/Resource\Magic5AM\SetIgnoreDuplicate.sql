UPDATE `_DebugSettingsForStart`
SET _allow_duplicate=:_allow_duplicate
WHERE _id=1
DELETE FROM _Users
WHERE _Users._UserId=:_UserId
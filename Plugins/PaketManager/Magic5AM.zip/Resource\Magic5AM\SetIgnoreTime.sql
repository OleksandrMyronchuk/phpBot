UPDATE `_DebugSettingsForStart`
SET _allow_incorrect_time=:_allow_incorrect_time
WHERE _id=1
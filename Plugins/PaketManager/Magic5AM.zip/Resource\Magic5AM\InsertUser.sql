INSERT INTO _Users
(_UserId,
_Username,
_FirstName,
_LastName)
VALUES
(:_UserId,
:_Username,
:_FirstName,
:_LastName);
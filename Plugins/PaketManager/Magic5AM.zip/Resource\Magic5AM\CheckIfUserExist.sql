SELECT COUNT(*) AS NumberOfUsers
FROM _Users WHERE
_UserId=:_UserId;